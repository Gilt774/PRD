import React from "react";
import Head from "next/head";
import { loadStripe } from "@stripe/stripe-js";
import axios from "axios";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY);

export default function Home() {
  const handleCheckout = async () => {
    const stripe = await stripePromise;
    const response = await axios.post("/api/checkout");
    const session = response.data;
    await stripe.redirectToCheckout({ sessionId: session.id });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
      <Head>
        <title>Gilt Farms And Tech</title>
        <meta name="description" content="Transforming Waste into Wealth | giltfarmstech.com" />
      </Head>
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-green-400">Gilt Farms And Tech</h1>
        <p className="text-gray-300 mt-2">
          Agriculture & Technology | Transforming Waste into Wealth
        </p>
      </header>
      <section className="grid md:grid-cols-2 gap-6 max-w-4xl">
        <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-semibold mb-2 text-green-300">Our Services</h2>
          <ul className="text-left space-y-2 text-gray-200">
            <li>Solar & Inverter Installation</li>
            <li>Bio-Tech & CCTV Systems</li>
            <li>Electrical/Electronics Repairs</li>
            <li>Catfish & Livestock Farming</li>
            <li>BSF Larvae, Pig, Crops & Palm</li>
            <li>Consultancy & General Contracts</li>
          </ul>
        </div>
        <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-semibold mb-2 text-green-300">Contact Us</h2>
          <p>Email: giltfarmstech@gmail.com</p>
          <p>Phone: +2349061749057</p>
          <p>
            Facebook:{" "}
            <a
              href="https://www.facebook.com/de.gilt.2025"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 underline"
            >
              Gilt Farms And Tech
            </a>
          </p>
          <button
            onClick={handleCheckout}
            className="mt-6 bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg text-white"
          >
            Pay / Support via Stripe
          </button>
        </div>
      </section>
      <footer className="mt-10 text-gray-500 text-sm">
        © {new Date().getFullYear()} giltfarmstech.com | Built for Gilt774
      </footer>
    </div>
  );
}
