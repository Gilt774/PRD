export default async function handler(req, res) {
  res.status(200).json({ id: "demo_session_id" });
}
